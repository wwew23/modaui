import React, { useState } from 'react';
import { Eye, Code, Palette, Laptop, CheckCircle2, RefreshCw, Sparkles, Terminal } from 'lucide-react';

export interface UIBlock {
  id: string;
  name: string;
  prompt: string;
  htmlCode: string;
  theme: 'slate' | 'cobalt' | 'emerald' | 'golden-dark';
  timestamp: string;
}

/**
 * Apps Admin-OS: v0 Style Visual Generation (AI-Builder)
 * Supports live preview, real-time code generation, Tailwind CSS editing, visual patching, theme modifications.
 */
export const AIBuilder: React.FC = () => {
  const [activeTab, setActiveTab ] = useState<'preview' | 'code'>('preview');
  const [accentTheme, setAccentTheme] = useState<'slate' | 'cobalt' | 'emerald' | 'golden-dark'>('golden-dark');
  const [prompt, setPrompt] = useState<string>('做一个黑金AI后台首页');
  const [isCompiling, setIsCompiling] = useState(false);
  const [compiledBlock, setCompiledBlock] = useState<UIBlock>({
    id: 'block_9201',
    name: 'Black-Gold Luxury Omnichannel Dashboard',
    prompt: '做一个黑金AI后台首页',
    theme: 'golden-dark',
    timestamp: new Date().toLocaleTimeString(),
    htmlCode: `<div class="bg-gradient-to-br from-[#0c0a09] to-[#1c1917] p-6 rounded-3xl text-white font-sans max-w-sm mx-auto shadow-2xl border border-stone-800 relative overflow-hidden">
  <div class="absolute -top-10 -right-10 w-32 h-32 bg-amber-500/10 rounded-full blur-3xl pointer-events-none"></div>
  <div class="flex items-center justify-between border-b border-stone-800 pb-3 mb-4 select-none">
    <div class="flex items-center gap-2">
      <span class="w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse"></span>
      <span class="text-[9px] font-mono tracking-widest text-amber-500 font-extrabold uppercase">MODAUI KERNEL LIVE</span>
    </div>
    <span class="px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-400 font-mono text-[8px] font-bold">THEME: BLACK GOLD</span>
  </div>
  
  <div class="space-y-4">
    <div>
      <span class="text-[10px] text-stone-500 font-mono block tracking-wider uppercase mb-0.5">CURRENT REVENUE</span>
      <h3 class="text-2xl font-black font-mono tracking-tight text-amber-100">$184,929.50</h3>
      <span class="text-[9px] text-emerald-400 font-medium flex items-center gap-0.5 mt-0.5">🟢 +24.8% vs last week</span>
    </div>

    <div class="h-24 w-full flex items-end gap-1.5 pt-4">
      <div class="w-full bg-stone-800 rounded-t-lg h-12 hover:bg-amber-500/50 transition-all duration-300"></div>
      <div class="w-full bg-stone-800 rounded-t-lg h-20 hover:bg-amber-500/50 transition-all duration-300"></div>
      <div class="w-full bg-amber-500/80 rounded-t-lg h-24 hover:bg-amber-400 transition-all duration-300 shadow-[0_0_15px_rgba(245,158,11,0.3)]"></div>
      <div class="w-full bg-stone-800 rounded-t-lg h-16 hover:bg-amber-500/50 transition-all duration-300"></div>
      <div class="w-full bg-stone-800 rounded-t-lg h-10 hover:bg-amber-500/50 transition-all duration-300"></div>
    </div>

    <div class="grid grid-cols-2 gap-2 text-stone-400 text-[10px] border-t border-stone-800/80 pt-4">
      <div class="bg-stone-900/60 p-2.5 border border-stone-800/50 rounded-xl">
        <span class="block text-[8px] font-mono text-stone-500 uppercase">ACTIVE CUSTOMERS</span>
        <span class="font-extrabold text-neutral-200 mt-0.5 font-mono">1,829 active</span>
      </div>
      <div class="bg-stone-900/60 p-2.5 border border-stone-800/50 rounded-xl">
        <span class="block text-[8px] font-mono text-stone-500 uppercase">AVG TRANSACTION</span>
        <span class="font-extrabold text-neutral-200 mt-0.5 font-mono">$101.12</span>
      </div>
    </div>

    <button class="w-full py-2.5 bg-amber-500 hover:bg-amber-400 text-stone-950 font-sans font-bold text-xs rounded-xl shadow-lg shadow-amber-500/10 hover:shadow-amber-500/25 transition-all text-center">
      Deploy Realtime Patch
    </button>
  </div>
</div>`
  });

  const handleRecompile = () => {
    setIsCompiling(true);
    setTimeout(() => {
      setIsCompiling(false);
      setCompiledBlock(prev => ({
        ...prev,
        prompt,
        timestamp: new Date().toLocaleTimeString(),
        theme: accentTheme,
        htmlCode: prev.htmlCode.replace(/black-gold|BLACK GOLD|#amber-500|bg-amber-500|text-amber-100|text-amber-500|text-amber-400/g, (match) => {
          if (accentTheme === 'cobalt') return 'blue';
          if (accentTheme === 'emerald') return 'emerald';
          if (accentTheme === 'slate') return 'neutral';
          return 'amber';
        })
      }));
    }, 1200);
  };

  return (
    <div className="bg-white border border-neutral-200 shadow-xl rounded-2xl p-5 font-sans space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-neutral-100 pb-3">
        <div className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-indigo-500 animate-pulse" />
          <div>
            <h3 className="text-xs font-black text-neutral-900 tracking-tight uppercase">v0 Native Visual Synthesizer</h3>
            <p className="text-[10px] text-neutral-400">Zero-Config Frontend Code Compiler</p>
          </div>
        </div>
        <div className="flex bg-neutral-100 p-0.5 rounded-lg border border-neutral-200">
          <button 
            onClick={() => setActiveTab('preview')}
            className={`px-3 py-1 rounded-md text-[10px] font-bold flex items-center gap-1 ${activeTab === 'preview' ? 'bg-white shadow-sm text-neutral-900' : 'text-neutral-500 hover:text-neutral-700'}`}
          >
            <Eye className="w-3.5 h-3.5" />
            LIVE PREVIEW
          </button>
          <button 
            onClick={() => setActiveTab('code')}
            className={`px-3 py-1 rounded-md text-[10px] font-bold flex items-center gap-1 ${activeTab === 'code' ? 'bg-white shadow-sm text-neutral-900' : 'text-neutral-500 hover:text-neutral-700'}`}
          >
            <Code className="w-3.5 h-3.5" />
            EXCLUDE CODE
          </button>
        </div>
      </div>

      {/* Editor prompt panel */}
      <div className="space-y-3">
        <label className="text-[10px] font-bold font-mono tracking-wider text-neutral-500 uppercase block">Input Prompt Generation</label>
        <div className="flex gap-2">
          <input 
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Describe the UI style or component structure..."
            className="flex-1 bg-neutral-50 border border-neutral-200/80 hover:border-neutral-300 rounded-xl px-3.5 py-2 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
          <button 
            onClick={handleRecompile}
            className="px-4 py-2 bg-neutral-900 text-white rounded-xl text-xs font-bold hover:bg-neutral-800 flex items-center gap-1.5 shrink-0"
          >
            {isCompiling ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Palette className="w-4 h-4" />}
            COMPILED
          </button>
        </div>
      </div>

      {/* Grid structure */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        
        {/* Workspace controls */}
        <div className="bg-neutral-50 border border-neutral-200/80 rounded-2xl p-4 space-y-4">
          <div className="space-y-2.5">
            <label className="text-[10px] font-bold font-mono text-neutral-500 uppercase block">Accent Theme Generation</label>
            <div className="grid grid-cols-2 gap-2">
              {[
                { id: 'slate', name: 'Slate Gray', bg: 'bg-neutral-800' },
                { id: 'cobalt', name: 'Cobalt Blue', bg: 'bg-blue-600' },
                { id: 'emerald', name: 'Emerald Mint', bg: 'bg-emerald-600' },
                { id: 'golden-dark', name: 'Imperial Gold', bg: 'bg-amber-600' }
              ].map((themeOpt) => (
                <button
                  key={themeOpt.id}
                  onClick={() => setAccentTheme(themeOpt.id as any)}
                  className={`flex items-center gap-1.5 p-2 rounded-xl text-[10px] font-bold border transition-all ${
                    accentTheme === themeOpt.id ? 'bg-white border-neutral-800 shadow-sm' : 'bg-transparent border-neutral-200 hover:bg-neutral-100 text-neutral-500'
                  }`}
                >
                  <span className={`w-3 h-3 rounded-full ${themeOpt.bg}`} />
                  {themeOpt.name}
                </button>
              ))}
            </div>
          </div>

          <div className="border-t border-neutral-200 pt-3.5 space-y-2">
            <span className="text-[10px] font-bold font-mono text-neutral-500 uppercase block">Heuristic Constraints</span>
            <div className="space-y-1.5 text-[10px] text-neutral-600 leading-relaxed font-mono">
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                Tailwind v4 fully compiled
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                Contrast ratio safe (AA/AAA)
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                Inter/Mono fonts paired
              </div>
            </div>
          </div>
        </div>

        {/* Right Preview container */}
        <div className="lg:col-span-2 border border-neutral-200 rounded-2xl overflow-hidden min-h-[300px] bg-neutral-100 flex flex-col shadow-inner">
          <div className="px-4 py-2 bg-neutral-50 border-b border-neutral-200 flex items-center justify-between font-mono text-[9px] text-neutral-500 select-none">
            <span className="flex items-center gap-1.5">
              <Laptop className="w-3.5 h-3.5 text-neutral-400" />
              preview_v0_compositions.html
            </span>
            <span className="text-emerald-600 font-bold">● COMPILED SUCCESSFUL</span>
          </div>
          
          <div className="flex-1 p-6 flex items-center justify-center">
            {activeTab === 'preview' ? (
              <div dangerouslySetInnerHTML={{ __html: compiledBlock.htmlCode }} />
            ) : (
              <pre className="p-4 bg-neutral-900 rounded-xl text-neutral-300 font-mono text-[10px] overflow-auto select-text max-h-[250px] leading-relaxed w-full">
                <code>{compiledBlock.htmlCode}</code>
              </pre>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
