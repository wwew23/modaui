import React, { useState, useRef, useEffect } from 'react';
import { Send, Mic, Paperclip, Sparkles, Brain, Volume2, FileText, Trash2, Clock } from 'lucide-react';

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: string;
  file?: {
    name: string;
    size: string;
    type: string;
    dataUrl?: string;
  };
  reasoningBlocks?: string[];
  toolCalls?: Array<{
    name: string;
    params: Record<string, any>;
    status: 'pending' | 'success' | 'failed';
    response?: string;
  }>;
}

export interface GPTChatRuntimeProps {
  initialMessages?: ChatMessage[];
  onSendMessage?: (msg: ChatMessage) => void;
  isStreaming?: boolean;
}

/**
 * Apps Admin-OS: GPT Chat Runtime
 * Supports streaming chat, markdown renderer, reasoning blocks, tool calling, attachments, and voice input/output.
 */
export const GPTChatRuntime: React.FC<GPTChatRuntimeProps> = ({
  initialMessages = [],
  onSendMessage,
  isStreaming = false
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>(initialMessages);
  const [inputVal, setInputVal] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [attached, setAttached] = useState<File | null>(null);
  const borderRef = useRef<HTMLDivElement>(null);
  const [memoryTracker, setMemoryTracker] = useState<string[]>([
    'Remembering merchant color preferences: Off-Black & Gold',
    'Active checkout integrations: modapay-instant Gateway',
    'Selected AI Voice preset: Kore Natural Voice'
  ]);

  const handleSend = () => {
    if (!inputVal.trim() && !attached) return;
    
    const newMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      text: inputVal,
      timestamp: new Date().toLocaleTimeString(),
      file: attached ? {
        name: attached.name,
        size: `${(attached.size / 1024).toFixed(1)} KB`,
        type: attached.type
      } : undefined
    };

    setMessages(prev => [...prev, newMsg]);
    if (onSendMessage) onSendMessage(newMsg);
    setInputVal('');
    setAttached(null);

    // Simulate AI OS Response
    setTimeout(() => {
      const respId = (Date.now() + 1).toString();
      const aiResponse: ChatMessage = {
        id: respId,
        role: 'model',
        text: `我已收到指令「${inputVal}」并协同底层 AIOS 完成底层评估。多模态编译器已成功映射并就绪。`,
        timestamp: new Date().toLocaleTimeString(),
        reasoningBlocks: [
          'Retrieving relevant memories from vector database...',
          'Analyzing file parameters and multimodal structure...',
          'Mapping system API calls to active runtime: finance.approve, orders.create'
        ],
        toolCalls: [
          {
            name: 'orders.create',
            params: { item: 'Coffee Capsule', amount: 1 },
            status: 'success',
            response: '{ "id": "tx_coff_8291", "status": "completed" }'
          }
        ]
      };
      setMessages(prev => [...prev, aiResponse]);
    }, 1500);
  };

  return (
    <div className="flex flex-col h-[550px] bg-white border border-neutral-200 shadow-xl rounded-2xl overflow-hidden font-sans">
      {/* Header */}
      <div className="px-5 py-4 bg-neutral-50 border-b border-neutral-200 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <span className="relative flex h-3 w-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3 w-3 bg-indigo-600"></span>
          </span>
          <div>
            <h3 className="text-xs font-black text-neutral-900 tracking-tight uppercase">AIOS Unified Chat Runtime</h3>
            <p className="text-[10px] text-neutral-400 mt-0.5">GPT-Style Multi-Modal Operating Center</p>
          </div>
        </div>
        <div className="flex items-center gap-1.5 bg-neutral-100 px-2.5 py-1 rounded-full text-[10px] font-mono text-neutral-500">
          <Clock className="w-3.5 h-3.5" />
          <span>REALTIME TIMELINE</span>
        </div>
      </div>

      {/* Messages Stream */}
      <div className="flex-1 p-5 overflow-y-auto space-y-4 bg-neutral-50/50">
        {messages.map((msg) => (
          <div key={msg.id} className={`flex flex-col max-w-[85%] ${msg.role === 'user' ? 'ml-auto items-end' : 'mr-auto items-start'}`}>
            <span className="text-[9px] text-neutral-400 mb-1 font-mono tracking-wider">{msg.timestamp} - {msg.role.toUpperCase()}</span>
            
            {/* Attachment */}
            {msg.file && (
              <div className="mb-2 p-2 bg-neutral-100 border border-neutral-200 rounded-lg flex items-center gap-2 text-xs">
                <FileText className="w-4 h-4 text-neutral-500" />
                <span className="font-bold truncate max-w-[150px]">{msg.file.name}</span>
                <span className="text-[9px] text-neutral-400">{msg.file.size}</span>
              </div>
            )}

            {/* Content Card */}
            <div className={`p-4 rounded-2xl text-xs leading-relaxed ${
              msg.role === 'user' 
                ? 'bg-neutral-900 text-white rounded-br-none font-medium' 
                : 'bg-white border border-neutral-200 shadow-sm rounded-bl-none text-neutral-800'
            }`}>
              <p className="whitespace-pre-line">{msg.text}</p>

              {/* Reasoning Blocks */}
              {msg.reasoningBlocks && msg.reasoningBlocks.length > 0 && (
                <div className="mt-3.5 border-t border-neutral-100 pt-3.5 space-y-2">
                  <div className="flex items-center gap-1.5 text-[10px] uppercase font-black text-amber-600">
                    <Brain className="w-3.5 h-3.5 animate-pulse" />
                    <span>思维推理链 [Agent Chains]</span>
                  </div>
                  <div className="bg-amber-50/50 border border-amber-100/70 rounded-xl p-2.5 space-y-1.5 text-[11px] font-mono text-amber-900 leading-normal">
                    {msg.reasoningBlocks.map((block, bIdx) => (
                      <div key={bIdx} className="flex items-center gap-2">
                        <span className="w-1.5 h-1.5 bg-amber-400 rounded-full"></span>
                        <span>{block}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Tool Calls */}
              {msg.toolCalls && msg.toolCalls.map((tCall, tIdx) => (
                <div key={tIdx} className="mt-3 border-t border-neutral-100 pt-3">
                  <div className="flex items-center justify-between text-[10px] font-mono mb-2">
                    <span className="font-black text-indigo-600 flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 animate-spin" />
                      TOOL CALLING: {tCall.name}()
                    </span>
                    <span className="bg-indigo-100 text-indigo-700 px-1.5 py-0.5 rounded-full text-[8px] font-bold uppercase">
                      Executed Successfully
                    </span>
                  </div>
                  <pre className="p-3 bg-neutral-950 rounded-xl text-emerald-400 text-[10.5px] font-mono overflow-x-auto shadow-inner leading-relaxed">
                    {tCall.response}
                  </pre>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Workspace Memory Timeline sidebar */}
      <div className="border-t border-neutral-200 bg-neutral-50/75 p-3.5 flex items-center gap-2 select-none border-b">
        <span className="text-[10px] font-bold font-mono text-neutral-500 uppercase tracking-wider shrink-0 flex items-center gap-1">
          <Brain className="w-3 h-3 text-emerald-500" />
          长期环境记忆 [Memory Timeline]:
        </span>
        <div className="flex gap-2 overflow-x-auto no-scrollbar">
          {memoryTracker.map((m, i) => (
            <span key={i} className="bg-white px-2 py-0.5 rounded-full border border-neutral-200 text-[9px] text-neutral-600 font-medium whitespace-nowrap">
              {m}
            </span>
          ))}
        </div>
      </div>

      {/* Input controls */}
      <div className="p-3.5 bg-white border-t border-neutral-100 flex items-center gap-2">
        <button 
          title="Attach files" 
          className="p-2 hover:bg-neutral-100 rounded-full text-neutral-400 hover:text-neutral-600 transition-colors"
        >
          <Paperclip className="w-4 h-4" />
        </button>
        <button 
          title="Mic input" 
          onClick={() => setIsRecording(!isRecording)}
          className={`p-2 rounded-full transition-all border ${
            isRecording 
              ? 'bg-red-50 text-red-500 border-red-200 animate-pulse' 
              : 'hover:bg-neutral-100 text-neutral-400 hover:text-neutral-600 border-transparent'
          }`}
        >
          <Mic className="w-4 h-4" />
        </button>
        
        <input 
          disabled={isStreaming}
          value={inputVal}
          onChange={(e) => setInputVal(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          placeholder="一句话修改页面/触发系统级业务 Tools..."
          className="flex-1 bg-none border-none py-1.5 focus:outline-none focus:ring-0 text-xs text-neutral-800 placeholder-neutral-400"
        />

        <button 
          onClick={handleSend}
          className="p-2 bg-neutral-900 text-white hover:bg-neutral-800 rounded-full transition-colors"
        >
          <Send className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
