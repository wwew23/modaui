export default globalThis.DOMException;
